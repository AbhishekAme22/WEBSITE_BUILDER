const editor = grapesjs.init({
  container: "#editor",
  fromElement: true,
  width: "auto",
  storageManager: false,
  plugins: ["gjs-preset-webpage"],
  pluginsOpts: {
    "gjs-preset-webpage": {},
  },
});
function abcd(){
  var html = editor.getHtml();
var css = editor.getCss();
console.log(html);
console.log(css);
}
