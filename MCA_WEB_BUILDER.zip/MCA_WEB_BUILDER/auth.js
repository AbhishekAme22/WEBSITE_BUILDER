//signup
if(sessionStorage.getItem("userid")==null){

}else{
    
    window.location.href="index.html";
}
const signupform = document.querySelector('#signup');
signupform.addEventListener('submit',(e)=>{

    e.preventDefault();
    //get user info 
    const name=signupform['name'].value;
    const email = signupform['email'].value;
    const password = signupform['password'].value;

    //signup the user
    
    auth.createUserWithEmailAndPassword(email,password).then(res=>{
        
        sessionStorage.setItem("userid", res.uid);
        window.location.href="index.html";
       

       // document.getElementById("name").innerHTML="welcome "+res.user.email;
       
       
        
    }).catch(err=>{
        signupform.querySelector("#errmsg").innerHTML=err.message;
    })

})


const loginform = document.querySelector('#Login');
loginform.addEventListener('submit',(e)=>{

    e.preventDefault();
    //get user info 
    const email = loginform['email'].value;
    const password = loginform['password'].value;

    //login the user
    
    auth.signInWithEmailAndPassword(email, password).then(res=>{
        
        sessionStorage.setItem("userid", res.uid);
        window.location.href="index.html";

       
        loginform.reset()
    }).catch(err=>{
        loginform.querySelector("#errmsg").innerHTML=err.message;
    })

})


//logout user
function logout(){
    auth.signOut();
   





}




